#include "DeckOfCards.h"
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

DeckOfCards::DeckOfCards()
:currentCard(0)
{
	for(int i=0; i<4; i++){
		for(int j=1; j<=13; j++){
			Card a(j, i);
			deck.push_back(a);	//�̹G 
		}
	}	
}
void DeckOfCards::shuffle(){
	srand(time(0));
	for(int i=0; i<52; i++){
		int j=rand()%52;
		swap(deck[i],deck[j]);
	}
	/*vector<Card>::const_iterator cii;
	for(cii=deck.begin(); cii!=deck.end(); cii++){
		int j=rand()%52;
		swap(cii,cii+j);
	}*/
}
Card DeckOfCards::dealCard(){
	Card a=deck[currentCard];
	currentCard++;
	return a;
}
bool DeckOfCards::moreCards() const{
	if(currentCard==51){
		return false;
	}
	return true;	
}
