#include "Card.h"
#include <string>

using namespace std;

Card::Card(int cardFace, int cardSuit){
	face=cardFace;
	suit=cardSuit;
}
const string Card::faceNames[totalFaces]={"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
const string Card::suitNames[totalSuits]={"Clubs", "Diamonds", "Hearts", "Spades"};
	
string Card::toString() const{
   string a=" ";
   a=faceNames[face-1]+" of "+suitNames[suit];
   return a;
}
